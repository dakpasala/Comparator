import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Comparator;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

import org.junit.Test;
import org.junit.Before;

public class TestCases
{
   Comparator<Song> cmpArt = ((one, two) -> one.getArtist().compareTo(two.getArtist()));
   Comparator<Song> cmpArt2 = (Comparator.comparing(Song::getArtist));
   private static final Song[] songs = new Song[] {
         new Song("Decemberists", "The Mariner's Revenge Song", 2005),
         new Song("Rogue Wave", "Love's Lost Guarantee", 2005),
         new Song("Avett Brothers", "Talk on Indolence", 2006),
         new Song("Gerry Rafferty", "Baker Street", 1998),
         new Song("City and Colour", "Sleeping Sickness", 2007),
         new Song("Foo Fighters", "Baker Street", 1997),
         new Song("Queen", "Bohemian Rhapsody", 1975),
         new Song("Gerry Rafferty", "Baker Street", 1978)
      };

   @Test
   public void testArtistComparator() {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("City and Colour", "Sleeping Sickness", 2007);
      ArtistComparator ac = new ArtistComparator();
      assertEquals(-2, ac.compare(one, two));

   }
   @Test
   public void testArtistComparator2() {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("Decemberists", "The Mariner's Revenge Song", 2005);
      ArtistComparator ac = new ArtistComparator();
      assertEquals(-3, ac.compare(one, two));

   }

   @Test
   public void testLambdaTitleComparator() {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("City and Colour", "Sleeping Sickness", 2007);
      Comparator<Song> cmpTitle = ((o, t) -> o.getTitle().compareTo(t.getTitle()));
      assertEquals(1, cmpTitle.compare(one, two));

   }

   @Test
   public void testLambdaTitleComparator2() {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("Decemberists", "The Mariner's Revenge Song", 2005);
      Comparator<Song> cmpTitle = ((o, t) -> o.getTitle().compareTo(t.getTitle()));
      assertEquals(-7, cmpTitle.compare(one, two));

   }

   @Test
   public void testYearExtractorComparator() {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("City and Colour", "Sleeping Sickness", 2007);
      Comparator<Song> cmpYear = (Comparator.comparing(Song::getYear));
      assertEquals(-1, cmpYear.compare(one, two));
   }

   @Test
   public void testYearExtractorComparator2() {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("Decemberists", "The Mariner's Revenge Song", 2005);
      Comparator<Song> cmpYear = (Comparator.comparing(Song::getYear));
      assertEquals(1, cmpYear.compare(one, two));
   }

   @Test
   public void testComposedComparator()
   {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("City and Colour", "Sleeping Sickness", 2007);
      Comparator<Song> cmpTitle = ((o, t) -> o.getTitle().compareTo(t.getTitle()));
      Comparator<Song> cmpYear = (Comparator.comparing(Song::getYear));
      ComposedComparator comp = new ComposedComparator(cmpYear, cmpTitle);
      assertEquals(-1, comp.compare(one, two));
   }

   @Test
   public void testComposedComparator2()
   {
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("Decemberists", "The Mariner's Revenge Song", 2005);
      Comparator<Song> cmpTitle = ((o, t) -> o.getTitle().compareTo(t.getTitle()));
      Comparator<Song> cmpYear = (Comparator.comparing(Song::getYear));
      ComposedComparator comp = new ComposedComparator(cmpYear, cmpTitle);
      assertEquals(1, comp.compare(one, two));
   }



   @Test
   public void testThenComparing() {
      Comparator<Song> cmpTitle = ((o, t) -> o.getTitle().compareTo(t.getTitle()));
      Comparator<Song> cmpArt = ((o, t) -> o.getArtist().compareTo(t.getArtist()));
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("Avett Brothers", "Sleeping Sickness", 2007);
      assertEquals(1, cmpTitle.thenComparing(cmpArt).compare(one, two));
   }

   @Test
   public void testThenComparing2() {
      Comparator<Song> cmpTitle = ((o, t) -> o.getTitle().compareTo(t.getTitle()));
      Comparator<Song> cmpArt = ((o, t) -> o.getArtist().compareTo(t.getArtist()));
      Song one = new Song("Avett Brothers", "Talk on Indolence", 2006);
      Song two = new Song("Decemberists", "The Mariner's Revenge Song", 2005);
      assertEquals(-7, cmpTitle.thenComparing(cmpArt).compare(one, two));
   }



   @Test
   public void runSort()
   {
      List<Song> songList = new ArrayList<>(Arrays.asList(songs));
      List<Song> expectedList = Arrays.asList(
         new Song("Avett Brothers", "Talk on Indolence", 2006),
         new Song("City and Colour", "Sleeping Sickness", 2007),
         new Song("Decemberists", "The Mariner's Revenge Song", 2005),
         new Song("Foo Fighters", "Baker Street", 1997),
         new Song("Gerry Rafferty", "Baker Street", 1978),
         new Song("Gerry Rafferty", "Baker Street", 1998),
         new Song("Queen", "Bohemian Rhapsody", 1975),
         new Song("Rogue Wave", "Love's Lost Guarantee", 2005)
         );
      Comparator<Song> cmpArt = ((o, t) -> o.getArtist().compareTo(t.getArtist()));
      Comparator<Song> cmpTitle = cmpArt.thenComparing((o, t) -> o.getTitle().compareTo(t.getTitle()));
      Comparator<Song> cmpYear = cmpTitle.thenComparing(Comparator.comparing(Song::getYear));

      songList.sort(cmpYear);


      assertEquals(songList, expectedList);
   }
}
